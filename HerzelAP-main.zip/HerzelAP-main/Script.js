<!-- Script untuk tombol sapa -->
  <script>
    // Ambil tombol berdasarkan ID
    const sapaButton = document.getElementById('sapaBtn');

    // Tambahkan event ketika tombol diklik
    sapaButton.addEventListener('click', function() {
      alert('Halo! Senang berkenalan denganmu 😊');
    });
  </script>
</body>
</html>
